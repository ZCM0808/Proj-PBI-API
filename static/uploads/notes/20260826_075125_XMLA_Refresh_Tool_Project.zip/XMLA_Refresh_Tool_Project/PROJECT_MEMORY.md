﻿# Power BI XMLA 个人交互式扫描与刷新工具项目记忆库 (PROJECT_MEMORY.md)

> **文档用途**：记录 Power BI XMLA 个人身份交互式语义模型/数据表/分区扫描与局部刷新工具的完整开发历程、排坑断言与终极成功架构。

---

## 1. 项目与工具概览 (Overview)
- **工具名称**：Power BI XMLA 个人交互式模型/表/分区定向刷新工具
- **目标端点**：`powerbi://api.powerbi.com/v1.0/myorg/DA_APAC_BI_QA`
- **核心功能**：
  1. 免配置 Service Principal，支持个人微软账号零门槛 OAuth2 极速弹窗登录；
  2. 自动枚举工作区下的所有 Datasets (语义模型)；
  3. 自动解包选择模型下的所有数据表 (Tables) 与物理分区 (Partitions)；
  4. 支持选择刷新类型 (`full`, `dataOnly`, `calculate`, `clearValues`) 并下发 TMSL/XMLA 刷新指令；
  5. 自动追踪本地历史记录 (最近 20 条)，支持一键重刷；
  6. 云端刷新记录自动转换为 UTC+8 北京时间，计算精确刷新耗时时长；
  7. 刷新后实时查询目标表当前的千分位格式真实总行数 (如 `154,230 行`)；
  8. 具备完善的层级导航 (`[0] 主菜单`, `[B] 上一步`)；
  9. **持久化 MSAL Token Cache (免重复网页弹窗登录)**。

---

## 2. 失败排坑与经验断言 (Failure Analysis & Lessons Learned)

### ❌ 踩坑 1：Windows 本地 MSOLAP 驱动身份验证失败
- **报错**：`Unable to obtain authentication token using the credentials provided.`
- **原因**：通过 PowerShell 脚本调用 TOM (Tabular Object Model) 的 `Server.Connect(xmlaEndpoint)` 时，MSOLAP 驱动不会自动唤起 Azure AD 交互登录框，而是直接送出 Windows 本地凭据导致被拒绝。

### ❌ 踩坑 2：PowerShell MSAL 4.x .NET 程序集类型转换冲突
- **报错**：`Cannot convert PublicClientApplicationBuilder to type PublicClientApplicationBuilder`
- **原因**：PowerShell 的 `.NET Framework` 宿主与安装的 `MSAL.PS` 模块依赖的 DLL 版本冲突，导致无法拉起原生的 OAuth2 登录窗口。

### ❌ 踩坑 3：纯 XMLA SOAP 接口返回空响应导致 XML 解析崩溃
- **报错**：`xml.etree.ElementTree.ParseError: no element found: line 1, column 0`
- **原因**：直接发送裸 `DISCOVER` 请求给 XMLA SOAP 接口在未授权/未携带格式参数时会关闭连接返回空字符串。

### ❌ 踩坑 4：每次运行都重复触发网页登录弹窗
- **原因**：默认 `PublicClientApplication` 未绑定持久化 `TokenCache`，导致每次进程重启都会视作新环境。
- **解决**：接入 `SerializableTokenCache` 并序列化落盘为 `msal_token_cache.bin`，优先调用 `acquire_token_silent` 实现无感无弹窗秒级连通。

---

## 3. 终极成功架构设计 (Successful Architecture)

1. **零驱动依赖与静默缓存 (Pure Python + MSAL + TokenCache)**：
   使用 Python `msal` 库配合官方公共 `Azure CLI Client ID` (`04b07795-8ddb-461a-bbee-02f9e1bf7b46`) 和 `organizations` 机构通用租户，结合本地加密缓存，实现极速免弹窗登录。
2. **三重防线元数据扫描 (包含 DAX COLUMNSTATISTICS 黑科技)**：
   - 防线一：发送 DAX `EVALUATE SUMMARIZE(COLUMNSTATISTICS(), [Table Name])` 突破 XMLA Token Audience 限制，100% 成功提取物理业务表名；
   - 防线二：发送 `DISCOVER_TMSL_METADATA` 并配合 `html.unescape()` 提取分区细粒度信息；
   - 防线三：提供优雅的手动输入表名/分区名通道与 Y/N 确认机制。
3. **混合双引擎刷新下发与状态审计**：
   优先通过 XMLA HTTP Execute SOAP 端点发送 TMSL 刷新 Payload；降级自动切至 Power BI Enhanced Refresh API。
   查询状态时自动转换为 UTC+8 时间，计算时长并利用 DAX `COUNTROWS` 查出最新行数。

---

## 4. 目录架构 (Directory Structure)

- **工具目录**：`C:\Users\ZCM\Desktop\XMLA_Refresh_Tool_Project\`
  - `PowerBI_XMLA_Interactive_Refresh.py` (核心 Python 引擎)
  - `运行PowerBI刷新工具.bat` (双击快捷启动入口)
  - `msal_token_cache.bin` (免弹窗 Token 加密缓存)
  - `PROJECT_MEMORY.md` (本项目专属记忆文件)